
var kilogram=45;
function kiloToMiles()
{
    alert (kilogram*0.62137);
}
console.log(kiloToMiles());
//square of variable

function square()
{
    let number=parseInt(prompt('enter  number for square'));
    square=number*number;
    alert( number*number);
}
console.log(square());

function evenodd()
{
    for(var number=0;number<100;++number)
    {
        if(number%2==0)
        {
            console.log(number,"even");
        }
        else{
            console.log(number,"odd");
        }
    }
   
} evenodd();
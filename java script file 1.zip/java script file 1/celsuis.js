// fahrenheit to celsius

//let f=parseInt(prompt('enter tampreture(celsius)'))
var f=345;
function tocelsius()
{
    
  alert((5/9)*(f-32));
}
console.log(tocelsius());


//celsius to fahrenheit
//let C=parseInt(prompt('enter tampreture(fahrenheit)'))
var C=456
function tofahrenheit()
{
    
  alert ((C*9/5)+32);
}
console.log(tofahrenheit());
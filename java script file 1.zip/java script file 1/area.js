//area of circle
var r=4;
function areaOfCircle()
{
 alert (3.14*r*r);
}
console.log(areaOfCircle());


//area of triangle
var height=10;
var base=20;
function areaOfTriangle()
{
    alert ((height*base)/2);
}
console.log(areaOfTriangle());

//area of rectangle
var lenght=10;
var width=20;
function areaOfRectangle()
{
    alert (width*lenght);
}
console.log(areaOfRectangle());

//area of square
var a=4;
function areaOfSquare()
{
 alert (a*a);
}
console.log(areaOfSquare());


//area of parallelogram
var base=100;
var verticalHeight=208;
function areaOfparallelogram()
{
    alert (base*verticalHeight);
}
console.log(areaOfparallelogram());